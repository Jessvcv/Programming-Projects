
public class Flights {

}
