/* Name: Jessica Tran
 * Date: 10/22/2023
 * Class: CSC 1120.01
 * Pledge: I have never given nor received unauthorized aid on this program.
 * Description: This program allows the user to create an account to buy an airline ticket and
 * to check if their password is a palindrome or not. They can check available flights along with book more
 * flights.
 * Input: You input a name, password, birthday, and pin.
 * Output: It checks if your password is a palindrome and allows the user to book, view, and schedule flights.
 * Introduction: This program allows the user to interact with an airline interface and check if their
 * password is a palindrome.
 */
import java.util.ArrayList;
import java.util.List;
public class Account {
    private String name;
    private String password;
    private String birthdate;
    private int pin;
    List<String> tickets;

    /*
     * Constructor for Account Class
     * @param name, password, birthdate, pin: allows construction of new account
     */
    public Account(String name, String password, String birthdate, int pin){
        this.name = name;
        this.password = password;
        this. birthdate = birthdate;
        this.pin = pin;
        tickets = new ArrayList<>();
    }
    /*
     * mutator method that allows the user to change the name to the input name
     * @param name: allows the user to change the name
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /*
     * mutator method that allows the user to change the password
     * @param password: allows the user to change the password
     */
    public void setPassword(String password)
    {
        this.password = password;
    }
    /*
     * mutator method that allows the user to change the birthdate
     * @param birthdate: allows the user to change the birthdate
     */
    public void setBirthdate(String birthdate)
    {
        this.birthdate = birthdate;
    }
    /*
     * mutator method that allows the user to change the pin
     * @param pin: allows the user to change the pin
     */
    public void setPin(int pin)
    {
        this.pin = pin;
    }
    /*
     * accessor method that allows the user to get the account name
     * @return name
     */
    public String getName()
    {
        return name;
    }
    /*
     * accessor method that allows the user to get the account password
     * @return password
     */
    public String getPassword()
    {
        return password;
    }
    /*
     * accessor method that allows the user to get the account birthdate
     * @return birthdate
     */
    public String getBirthdate()
    {
        return birthdate;
    }
    /*
     * accessor method that allows the user to get the account pin
     * @return pin
     */
    public int getPin()
    {
        return pin;
    }
    /*
     * accessor method that allows the user to get the account pin
     * @return pin
     */
    public void addTickets(String t){
        tickets.add(t);
    }
    /*
     * accessor method that allows the user to get the account pin
     * @return tickets
     */
    public void getTickets(){
        for(int i = 0; i < tickets.size(); i++) {
            System.out.println(tickets.get(i));
        }
    }

    /*
     * Checks if the password is a palindrome
     * A palindrome is a word that is the same spelled backwards
     */
    public void checkPalindrome()
    {
        password.toLowerCase();
        String backward = "";
        /*
         * this takes the password and reverses the order of the characters to add to another string
         * that string can now be used to compared to the original password to check if it is
         * a palindrome
         * it prints if the password is a palindrome or not
         */
        for(int i = password.length()-1; i >= 0; i--){
            backward += password.charAt(i);
        }

        if (password.equals(backward)){
            System.out.println("Your password " + password + " is a palindrome.");
        }else{
            System.out.println("Your password is not a palindrome.");
        }

    }
}
