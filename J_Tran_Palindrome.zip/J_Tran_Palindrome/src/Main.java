import java.util.ArrayList;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<String> flights = new ArrayList<>();
        flights.add("Tallahassee to New York   DELTA       11:00AM   $500");
        flights.add("Juno to Milwaukee         UNITED      11:00AM   $250");
        flights.add("Tuscon to to Nashville    SOUTHWEST   09:00PM   $970");
        flights.add("Branson to Arlen          UNITED      02:00PM   $450");
        flights.add("Atlanta to Chicago        DELTA       02:00AM   $600");
        flights.add("Atlanta to San Francisco  NORTHWEST   11:30AM   $350");

        System.out.println("_________________________________");
        System.out.println("  Jessica Airlines Incorporated  ");
        System.out.println("_________________________________");
        System.out.println("Do you have an account?");
        System.out.println("Please enter the account name.");
        String n = scan.nextLine();
        System.out.println("Please enter the user's birthday. (MM/DD/YYYY)");
        String b = scan.nextLine();
        System.out.println("Please enter the account password. (all lowercase)");
        String p = scan.nextLine();
        System.out.println("Enter the 4 digit account pin?");
        int pin = scan.nextInt();
        Account account = new Account(n, p, b, pin);
        System.out.println(n + "'s Account Details:");
        System.out.println(" Birthday: " + b);
        System.out.println(" Password: " + p);
        System.out.println(" Pin: " + pin);
        account.checkPalindrome();
        System.out.println("______________________________________________");
        System.out.println("1: View available flights");
        System.out.println("2: Book a ticket");
        System.out.println("3: View your ticket(s)");
        System.out.println("4: Change your password");
        System.out.println("5: Quit");
        System.out.println("How can we help you today?");
        System.out.println("Enter a number 1-5: ");
        System.out.println("______________________________________________");

        boolean run = true;
        while (run) {
            int num = scan.nextInt();
            if (num == 1)
            {
                for(int i = 0; i < flights.size(); i++) {
                    System.out.println(flights.get(i));
                }
            }
            if (num == 2)
            {
                System.out.println("Which flight would you like to book?");
                System.out.println("Insert the number associated with the flight: ");
                for(int i = 0; i < flights.size(); i++) {
                    System.out.println((i + 1) + ": " + flights.get(i));
                }
                int nu = scan.nextInt();
                account.addTickets(flights.get(nu-1));
            }
            if (num == 3)
            {
                account.getTickets();
            }
            if (num == 4)
            {
                System.out.println("Create New Password: ");
                p = scan.next();
                account.setPassword(p);
                System.out.println(n + "'s Account Details:");
                System.out.println(" Birthday: " + b);
                System.out.println(" Password: " + p);
                System.out.println(" Pin: " + pin);
                account.checkPalindrome();

            }
            if (num != 5)
            {
                System.out.println("______________________________________________");
                System.out.println("1: View available flights");
                System.out.println("2: Book a ticket");
                System.out.println("3: View your ticket(s)");
                System.out.println("4: Change your password");
                System.out.println("5: Quit");
                System.out.println("How can we help you today?");
                System.out.println("Enter a number 1-5: ");
                System.out.println("______________________________________________");
            }
            if (num == 5) {
                run = false;
            }

        }
        System.out.println("Thank you for choosing Jessica Airlines Incorporated!");
    }
    /*
     * In conclusion, I used data structures such as ArrayList to add flights to the account and for loops
     * to check for palindrome passwords.
     */
}