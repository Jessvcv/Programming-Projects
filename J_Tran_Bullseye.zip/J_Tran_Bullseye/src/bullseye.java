import java.util.ArrayList;
import java.util.List;
/* Name: Jessica Tran
 * Date: 12/07/2023
 * Class: CSC 1120
 * Pledge: I have neither given nor received unauthorized aid on this program.
 * Description: This program scores points scored from 2 players during a game of darts.
 * The coordinates of the darts are from a file of coordinates. The player with the most points wins.
 * Scores are computed by the area the darts lands on
 * Input: This code reads a file of coordinates of the players.
 * Output: The program displays the winner and points after playing.
 */
public class bullseye {
    List<String> player1 = new ArrayList<>();
    //This list holds the first player's coordinates
    List<String> player2 = new ArrayList<>();
    //This list holds the second player's coordinates
    public bullseye() {

    }

    /**
     * Score calculates the score of the game based on coordinates using radius formula
     * @param x, x coordinate on dart board
     * @param y, y coordinate on dart board
     * @return score of the darts
     */
    public int score(double x, double y) {
        int score = 0;
        double radius = Math.sqrt(Math.pow(x,2) + Math.pow(y,2));

        if(radius <= 4) {
            score = 100;
        }
        else if(radius > 4 && radius <= 8) {
            score = 80;
        }
        else if(radius > 8 && radius <= 12) {
            score = 60;
        }
        else if(radius > 12 && radius <= 16) {
            score = 40;
        }
        else if(radius > 16 && radius <= 20) {
            score = 20;
        }
        else if (radius > 20) {
            score = 0;
        }
        return score;
    }

    /**
     * This function calculates the total score for player one.
     * @param coordinates, Arraylist that holds the coordinates
     * @param index, holds the index that the player is currently at
     * @return totalScore, score of player one
     */
     public int playerOne(List<Double> coordinates, int index){
         //adds coordinates of one round of darts for player one for one round of darts
         for(int i = 0; i < 5; i = i+2) {
             player1.add(coordinates.get(index + i) + "," + coordinates.get((index + i)+1));
         }
         int s = player1.size();
         int c = 2;
         int totalScore = 0;
         //2D array that holds coordinates of player one
         double[][] player1Coordinates = new double[s][c];

         //adds coordinates into the 2D array
         for(int i = 1; i <= s; i++) {
             String[] parts = player1.get(i-1).split(",");
             player1Coordinates[i-1][0] = Double.parseDouble(parts[0]);
             player1Coordinates[i-1][1] = Double.parseDouble(parts[1]);
         }

         //the outer loop increments through the games
         //the inner loop adds the scores for one game
         for(int m = (player1Coordinates.length)-3; m < player1Coordinates.length; m=m+3){
             for(int i = 0; i < 3; i++){
                 totalScore += score(player1Coordinates[m+i][0], player1Coordinates[m+i][1]);
             }
         }

         return totalScore;
     }

    /**
     * This function calculated the total score for player two
     * @param coordinates, ArrayList of coordinates
     * @param index, holds the index that the player is at
     * @return totalScore
     */
     public int playerTwo(List<Double> coordinates, int index) {
         //adds coordinates of one round of darts for player one for one round of darts
         for(int i = 6; i < 11; i = i + 2) {
             player2.add(coordinates.get(index + i) + "," + coordinates.get((index + i) + 1));
         }

         int s = player2.size();
         int c = 2;
         int totalScore = 0;
         //2D array that holds coordinates of player one
         double[][] player2Coordinates = new double[s][c];

         //adds coordinates into the 2D array
         for( int i = 1; i <= s; i++) {
             String[] parts = player2.get(i-1).split(",");
             player2Coordinates[i-1][0] = Double.parseDouble(parts[0]);
             player2Coordinates[i-1][1] = Double.parseDouble(parts[1]);
         }

         //the outer loop increments through the games
         //the inner loop adds the scores for one game
         for(int m = (player2Coordinates.length)-3; m < player2Coordinates.length; m=m+3) {
             for(int i = 0; i < 3; i++) {
                 totalScore += score(player2Coordinates[m+i][0], player2Coordinates[m+i][1]);
             }
         }
         return totalScore;
     }
}
