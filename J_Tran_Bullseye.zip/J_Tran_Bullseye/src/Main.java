import java.sql.Array;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public Main(){

    }
    public static void main(String[] args) throws FileNotFoundException{
        //bullseye object
        bullseye bull = new bullseye();
        //ArrayList will hold the coordinates
        List<Double> coordinates = new ArrayList();
        //scans in the coordinates from the file
        Scanner scan = new Scanner(new File("/Users/jessicatran/Downloads/J_Tran_Bullseye/coordinates.txt"));
        //adds the coordinates from the file into the list
        while(scan.hasNext()) {
             coordinates.add(scan.nextDouble());
         }
        //the loop increments through the coordinates list by adding 12
         for(int i = 0; i < coordinates.size(); i = i+12) {
             //stores scores of each player for each round
             int score1 = bull.playerOne(coordinates,i);
             int score2 = bull.playerTwo(coordinates,i);
             //prints scores and results of the game
             if(score1 > score2) {
                 System.out.println("SCORE: " + score1 + " to " + score2 + ", PLAYER 1 WINS.");
             }
             else if(score1 < score2) {
                 System.out.println("SCORE: " + score1 + " to " + score2 + ", PLAYER 2 WINS.");
             }
             else if(score1 == score2) {
                 System.out.println("SCORE: " + score1 + " to " + score2 + ", TIE.");
             }
         }
    }
}