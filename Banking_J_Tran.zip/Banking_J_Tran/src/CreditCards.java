public class CreditCards extends Account{
    private int cardNumber;
    private String[] last10charges;
    public CreditCards() {
        name = "Jessica";
        taxID = 123456;
        balance = 1000;
        last10charges = new String[10];
    }
    public CreditCards(String Name, int id, double Balance) {
        name = Name;
        taxID = id;
        balance = Balance;
        last10charges = new String[10];
    }
    public void DebitCharge(String name, double amount) {
        balance = balance - amount;
        numWithdraws++;
        for(int i = 9; i > 0; i--) {
            last10withdraws[i] = last10withdraws[i - 1];
        }
        last10withdraws[0] = amount;
    }
    public void makePayment(double amount){
        balance += amount;
        numDeposits++;
        for(int i = 9; i > 0; i--) {
            last10deposits[i] = last10deposits[i - 1];
        }
        last10deposits[0] = amount;
    }
    public void display(){
        System.out.println("Name: " + name);
        System.out.println("Last charge on card: " + last10deposits[0]);
        System.out.println("Record of last 10 deposits on credit card:");
        for(int i = 0; i < last10deposits.length; i++) {
            System.out.print(last10deposits[i]);
        }
    }
}
