/*
 * Name: Jessica Tran
 * Date: 9/23/2023
 * Class: CSC 1120.01
 * Pledge: I have neither given nor received unauthorized aid on this program.
 * Description: The Bank Account Class allows for updates and modification of the child classes.
 * Input: The user inputs numbers as commands to edit and view the accounts.
 * Output: The program displays the transactions, balance, and display depending on user input.
 */
public class Account {
    //protected variables allows child classes to access
    protected String name;
    protected int taxID;
    protected double balance;
    protected double[] last10withdraws;
    protected double[] last10deposits;
    protected int numDeposits;
    protected int numWithdraws;
    //default constructor

    public Account() {
        name = "Jessica Tran";
        taxID = 123456;
        balance = 750.80;
        last10deposits = new double[] {0,0,0,0,0,0,0,0,0,0};
        last10withdraws = new double[] {0,0,0,0,0,0,0,0,0,0};
    }
    //constructor that allows customization through parameters
    public Account(String Name, int id, double Balance) {
        name = Name;
        taxID = id;
        balance = Balance;
        last10deposits = new double[] {0,0,0,0,0,0,0,0,0,0};
        last10withdraws = new double[] {0,0,0,0,0,0,0,0,0,0};
    }
    //mutator methods
    //sets value of name
    public void setName(String Name) {
        name = Name;
    }
    //sets value of taxID
    public void setTaxID(int id) {
        taxID = id;
    }
    //sets value of balance
    public void setBalance(double value) {
        balance = value;
    }
    //accessor methods
    //returns name
    public String getName() {
        return name;
    }
    //returns taxID
    public int getTaxID() {
        return taxID;
    }
    //returns balance
    public double getBalance() {
        return balance;
    }
    //used to add deposit to account
    public void makeDeposit(double amount) {
        balance = balance + amount;
        numDeposits++;
        for (int i = 9; i > 0; i--) {
            last10deposits[i] = last10deposits[i-1];
        }
        last10deposits[0] = amount;
    }
    //used to show information about the account
    public void display ()
        {
            System.out.println("Name: " + name);
            System.out.println("Tax ID: " + taxID);
            System.out.println("Balance: " + balance);
        }
    }

