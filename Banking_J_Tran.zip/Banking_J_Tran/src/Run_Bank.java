/* Conclusion: This program is meant to allow the user to add, remove, and
check their accounts. It mimics banking apps.
 */
import java.util.Scanner;
public class Run_Bank {
    public static void main(String [] args) {
        Checking c1 = new Checking("Checking", 12345, 100.0);
        Savings s1 = new Savings("Savings", 23456, 100.0);
        CreditCards cc1 = new CreditCards("Credit Cards", 34567, 100.0);
        Scanner scan = new Scanner(System.in);
        boolean exit = false;
        while(!exit){
            System.out.println("Bank of Vietnam: ");
            System.out.println("1. Savings Deposit");
            System.out.println("2. Savings Withdrawal");
            System.out.println("3. Checking Deposit");
            System.out.println("4. Write A Checking");
            System.out.println("5. Credit Card Payment");
            System.out.println("6. Make A Charge");
            System.out.println("7. Display Savings");
            System.out.println("8. Display Checking");
            System.out.println("9. Display Credit ");
            System.out.println("10. Exit");
            System.out.println("Enter menu selection here:");
            int next = scan.nextInt();
            if(next > 10){
                System.out.println("Invalid input, please try again!");
            }
            if(next == 1){
                System.out.println("Enter amount: ");
                s1.makeDeposit(scan.nextDouble());
                System.out.println("Deposit was successful!");
                System.out.println("Savings Balance: " + s1.getBalance());
            }
            if(next == 2){
                System.out.println("Enter amount: ");
                s1.doWithdraw(scan.nextDouble());
                System.out.println("Withdrawal was successful!");
                System.out.println("Savings Balance: " + s1.getBalance());
            }
            if(next == 3){
                System.out.println("Enter amount: ");
                c1.makeDeposit(scan.nextDouble());
                System.out.println("Deposit was successful!");
                System.out.println("Checking Balance: " + c1.getBalance());
            }
            if(next == 4){
                System.out.println("Enter Check Number: ");
                int num = scan.nextInt();
                System.out.println("Enter amount: ");
                c1.writeCheck(num, scan.nextDouble());
                System.out.println("Withdrawal was successful!");
                System.out.println("Checking Balance: " + c1.getBalance());
            }
            if(next == 5){
                System.out.println("Enter amount: ");
                cc1.makeDeposit(scan.nextDouble());
                System.out.println("Deposit was successful!");
                System.out.println("Credit Card Balance: " + cc1.getBalance());
            }
            if(next == 6){
                System.out.println("Enter name: ");
                String n = scan.next();
                System.out.println("Enter amount: ");
                cc1.DebitCharge(n, scan.nextDouble());
                System.out.println("Withdrawal was successful!");
                System.out.println("Credit Card Balance: " + cc1.getBalance());
            }
            if(next == 7) {
                s1.display();
            }
            if(next == 8) {
                c1.display();
            }
            if(next == 9) {
                cc1.display();
            }
            if(next == 10) {
                System.out.println("Bye!");
                exit = true;
            }
        }
        System.exit(0);
    }

}
