//This class functions as a savings account and extends Account class.
public class Savings extends Account{
    public Savings()
    {
        name = "Jessica";
        taxID = 123456;
        balance = 1000;
    }
    public Savings(String Name, int id, double Balance)
    {
        name = Name;
        taxID = id;
        balance = Balance;
    }

    public void doWithdraw(double amount)
    {
        balance = balance - amount;
        numWithdraws++;
        for(int i = 9; i > 0; i--)
        {
            last10withdraws[i] = last10withdraws[i-1];
        }
        last10withdraws[0] = amount;
    }
    public void display()
    {
        System.out.println("Record of last 10 withdraws from Savings Account: ");
        for(int i = 0; i < last10withdraws.length; i++)
        {
            System.out.println(last10withdraws[i]);
        }
        System.out.println("Record of last 10 deposits from Savings Account: ");
        for(int i = 0; i < last10deposits.length; i++)
        {
            System.out.println(last10deposits[i]);
        }
    }
}
