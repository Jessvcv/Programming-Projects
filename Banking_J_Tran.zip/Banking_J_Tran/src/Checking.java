public class Checking extends Account{
    private int[] last10checks;
    private int checkNumber;
    public Checking()
    {
        name = "Jessica";
        taxID = 123456;
        balance = 1000;
        last10checks = new int[]{0,0,0,0,0,0,0,0,0,0};
    }
    public Checking(String Name, int id, double Balance)
    {
        name = Name;
        taxID = id;
        balance = Balance;
        last10checks = new int[]{0,0,0,0,0,0,0,0,0,0};
    }
    public void writeCheck(int checknum, double amount)
    {
        balance = balance - amount;
        numWithdraws++;
        for(int i = 9; i > 0; i--)
        {
            last10withdraws[i] = last10withdraws[i-1];
        }
        checkNumber = checknum;
        last10withdraws[0] = amount;
    }
    public void display() {
        System.out.println("Check Register: ");
        System.out.println("Check Number: " + checkNumber);
        System.out.println("Amount:" );
        System.out.println("Record of Last 10 Deposits for Checking: ");
        for(int i = 0; i < last10checks.length; i++) {
            System.out.println(last10checks[i]);
        }
    }
}
