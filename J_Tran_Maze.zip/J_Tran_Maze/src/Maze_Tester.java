import java.util.*;
import java.io.*;

public class Maze_Tester
{
    /**
     * Creates a new maze, prints its original form, attempts to
     * solve it, and prints out its final form.
     */
    public static void main(String[] args) throws FileNotFoundException
    {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the file pathway of the file containing the maze: ");
        String filename = scan.nextLine();
        Maze labyrinth = new Maze(filename);
        Maze_Solver solver = new Maze_Solver(labyrinth);
        if (solver.traverse(solver.getRatX(), solver.getRatY())) {
            System.out.println("The maze was successfully traversed!");
            System.out.println("Traverse was called " + solver.getTriedNum() + " times.");
            System.out.println("There are "+ solver.getBreadcrumbs() + " breadcrumbs.");
            System.out.println("Solution:");
        }
        else {
            System.out.println("There is no possible path.");
        }
        System.out.println(labyrinth);
    }
}