import java.util.*;
import java.io.*;
/*
 * Name: Jessica Tran
 * Date: 11/18/2023
 * Pledge: I have no received or gave unauthorized aid on this program.
 * Description: This program uses recursive methods to guide a rat through a maze. The goal
 * is for the rat to find the cheese from a starting point.
 * Input: The user inputs a maze file.
 * Output: The program displays the maze that was input, the solution to the maze, coordinates
 * of the rat's movements, how many breadcrumbs there are, visual of solved maze, and how many times
 * recursion is used.
 */

/**
 * Maze represents a maze of characters. The goal is to get from the R position to the
 * C position. 'o' are used to represent locations in the maze that have been TRIED
 * and that are part of the solution PATH.
 *
 * @author Jessica Tran
 * @version 11.19.2023
 */
public class Maze {
    private static final char TRIED = 't';
    private static final char PATH = 'o';
    private int numberRows, numberColumns;
    private char[][] grid;
    private int ratX;
    private int ratY;
    private String maze = "";
    private int triedNum;
    private int breadcrumbs;


    /**
     * Constructor for the Maze class. Loads a maze from the given file.
     * Throws a FileNotFoundException if the given file is not found.
     *
     * @param filename the name of the file to load
     * @throws FileNotFoundException if the given file is not found
     */
    public Maze(String filename) throws FileNotFoundException {
        Scanner scan = new Scanner(new File(filename));
        numberRows = 0;
        triedNum = 0;
        breadcrumbs = 0;
        while (scan.hasNextLine()) {
            if (maze == "") {
                maze += scan.nextLine();
                numberColumns = maze.length();
                numberRows++;
            } else {
                maze += scan.nextLine();
                numberRows++;
            }
        }

        grid = new char[numberRows][numberColumns];
        for (int i = 0; i < numberRows; i++) {
            for (int j = 0; j < numberColumns; j++) {
                grid[i][j] = maze.charAt(i * numberColumns + j);
                if (grid[i][j] == 'R') {
                    ratX = i;
                    ratY = j;
                }
            }
        }
    }

    /**
     * Accessor for number of breadcrumbs
     *
     * @return number of breadcrumbs
     */
    public int getBreadcrumbs() {
        return breadcrumbs;
    }

    /**
     * Accessor for the amount of spots the maze checked or number of
     * times the recursive method is called.
     *
     * @return the amount of tries the maze took to solve
     */
    public int getTriedNum() {
        return triedNum;
    }

    /**
     * Returns the x-coordinate of the rat's position
     *
     * @return x-coordinate of rat's position
     */
    public int getRatX() {
        return ratX;
    }

    /**
     * Returns the y-coordinate of the rat's position
     *
     * @return y-coordinate of rat's position
     */
    public int getRatY() {
        return ratY;
    }

    /**
     * Find if the specified position is where the cheese is located
     *
     * @param row the index of the row
     * @param col the index of the column
     */
    public boolean cheeseLocation(int row, int col) {
        if (grid[row][col] == 'C') {
            return true;
        }
        return false;
    }

    /**
     * Marks the specified position in the maze as TRIED
     * Prints out the current location of the rat
     *
     * @param row the index of the row to try
     * @param col the index of the column to try
     */
    public void tryPosition(int row, int col) {
        if (grid[row][col] != 'C') {
            grid[row][col] = TRIED;
        }
        System.out.println("The rat went to " + row + ", " + col + ".");
        triedNum++;
    }

    /**
     * Marks a given position in the maze as part of the PATH
     *
     * @param row the index of the row to mark as part of the PATH
     * @param col the index of the column to mark as part of the PATH
     */
    public void markPath(int row, int col) {
        if (grid[row][col] != 'C') {
            grid[row][col] = PATH;
            breadcrumbs++;
        }
    }

    /**
     * Determines if a specific location is valid. A valid location
     * is one that is on the grid, is not blocked, and has not been TRIED.
     *
     * @param row    the row to be checked
     * @param column the column to be checked
     * @return true if the location is valid
     */
    public boolean validPosition(int row, int column) {
        boolean result = false;

        // check if cell is in the bounds of the matrix
        if (row >= 0 && row < grid.length &&
                column >= 0 && column < grid[row].length)

            //  check if cell is not blocked and not previously tried
            if (grid[row][column] != 't' && grid[row][column] != '#')
                result = true;

        return result;
    }

    /**
     * Returns the maze as a string.
     *
     * @return a string representation of the maze
     */
    public String toString() {
        String result = "\n";

        for (int row = 0; row < grid.length; row++)
        {
            for (int column = 0; column < grid[row].length; column++) {
                if (grid[row][column] == 't') {
                    result += maze.charAt(row * numberColumns + column) + "";
                } else {
                    result += grid[row][column] + "";
                }
            }
            result += "\n";
        }
        return result;
    }
}

