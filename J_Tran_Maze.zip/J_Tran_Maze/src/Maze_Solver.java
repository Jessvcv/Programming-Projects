/**
 * Maze_Solver recursively traverses through a maze. The goal is to get the rat to the cheese.
 * The char 'o' is used to represents breadcrumbs that show the path to the cheese. The
 * char '.' represents the available paths that the rat can take.
 */

public class Maze_Solver {
    private Maze maze;
    public Maze_Solver(Maze maze) {
        this.maze = maze;
    }
    public int getBreadcrumbs()
    {
        return maze.getBreadcrumbs();
    }

    public int getTriedNum()
    {
        return maze.getTriedNum();
    }

    public int getRatX()
    {
        return maze.getRatX();
    }

    public int getRatY()
    {
        return maze.getRatY();
    }

    /**
     * This method recursively traverses through the maze. The method tries the north, south, east and
     * west directions and indicates if it part of the final path to the cheese using the boolean
     * variable.
     * @param row
     * @param column
     * @return done (true or false)
     */
    public boolean traverse(int row, int column) {
        boolean done = false;
        if (this.maze.validPosition(row, column)) {
            this.maze.tryPosition(row, column);
            if (maze.cheeseLocation(row, column)) {
                done = true;
            } else {
                done = this.traverse(row + 1, column);
                if (!done) {
                    done = this.traverse(row, column + 1);
                }

                if (!done) {
                    done = this.traverse(row - 1, column);
                }

                if (!done) {
                    done = this.traverse(row, column - 1);
                }
            }

            if (done) {
                this.maze.markPath(row, column);
            }
        }

        return done;
    }
}
