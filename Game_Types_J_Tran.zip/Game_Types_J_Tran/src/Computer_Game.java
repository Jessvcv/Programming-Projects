public class Computer_Game extends Game{
   int points;
    @Override
    public void setDescription(String input) {
        super.setDescription(input);
    }
    public void setDescription(String input, int value) {
        description = input;
        points = value;
    }
    @Override
    public String getDescription() {
        return super.getDescription();
    }
    public String getDescription()
    {
        return description + points;
    }
}
