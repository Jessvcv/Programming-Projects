public class Board_Game extends Game{
   int num_player;
   int time;
   public Board_Game(String description, int player, int time)
   {
       description = description;
       num
   }
    @Override
    public void setDescription(String input) {
        super.setDescription(input);
    }
    @Override
    public String getDescription() {
        return super.getDescription();
    }
    public void setNumPlayer(int value)
    {
        num_player = value;
    }
    public int getNumPlayer()
    {
        return num_player;
    }
    public void setTimeLimit(int limit)
    {
        time = limit;
    }
    public int getTime()
    {
        return time;
    }
}
