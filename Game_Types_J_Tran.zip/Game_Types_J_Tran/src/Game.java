public class Game {
    String description;
    public Game()
    {
    }
    public void setDescription(String input)
    {
        description = input;
    }
    public String getDescription()
    {
        return description;
    }
}
