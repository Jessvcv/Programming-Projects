public class Run_Game {
    Board_Game monopoly = new Board_Game();

}
